def map_params(**kwargs):
    return kwargs


if __name__ == '__main__':
    map_params()